##REFERENCE:
 
##https://m...content-available-to-author-only...m.com/swlh/lets-write-a-chat-app-in-python-f6783a9ac170?fbclid=IwAR1PEA5Bxaglt6l_ojyzeYSht772Ut-mYzvNjuNdps90Iq_H0MAbDbR2cj0
"""Script for Tkinter GUI chat client."""
from socket import AF_INET, socket, SOCK_STREAM
from threading import Thread
import tkinter
import base64
import hashlib, uuid
from tkinter import *  
from PIL import ImageTk, Image  
import cv2
from stegano import lsbset
from stegano.lsbset import generators
from cryptosteganography import CryptoSteganography
import io

from tkinter import ttk

from database import users

def pad(s, bs):
    return s.ljust(bs, b"\x0f")

def unpad(s):
    return s.rstrip(b'\x0f') 

def receive():
    """Handles receiving of messages."""
    while True:
        try:
            received_data = client_socket.recv(BUFSIZ)
            received_data = unpad(received_data)
            if 'size:' == (received_data[:len('size:')]).decode("utf8"):
                print('Receiving size')
                received_message = received_data.decode("utf8")
                split_message = received_message.split(":")
                length = int(split_message[1])
                sender_name = split_message[2]

                image_path = 'received_image.png'

                data = b''
                while(len(data) < length):
                    data += client_socket.recv(BUFSIZ)

                print('image received')

                image = Image.open(io.BytesIO(data))
                image.save(image_path)

                decoded_message = crypto_steganography.retrieve(image_path)
                message = sender_name + ': ' + decoded_message
            else:
                print('Receiving something else')
                message = received_data.decode("utf8")

            msg_list.insert(tkinter.END, message)
 
        except OSError as e:  # Possibly client has left the chat.
            print('OS ERROR')
            print(str(e))
            break 


   
 
def send(event=None):  # event is passed by binders.
    """Handles sending of messages."""
    msg = my_msg.get()
    my_msg.set("")

    if msg == "{quit}":
        msg = bytes(msg, "utf8")
        msg = pad(msg, BUFSIZ)
        client_socket.send(msg)
        client_socket.close()
        top.quit()
    elif msg.startswith("send to") | msg.startswith("reply to") | msg.startswith("GetAllContacts") | msg.startswith("back"):
        msg = bytes(msg, "utf8")
        msg = pad(msg, BUFSIZ)
        client_socket.send(msg)
    else:
        secret_image_name = "secret_image.png"
        crypto_steganography.hide('image.png', secret_image_name, msg)

        image = open(secret_image_name, 'rb').read()
        image_size = len(image)
        
        msg = bytes("size:" + str(image_size), "utf8")
        msg = pad(msg, BUFSIZ)
        client_socket.send(msg)
        client_socket.sendall(image)


        print("SIZE", image_size)
    
def login_signup(event=None):
    print('LOGIN')
    name = my_name.get()
    my_name.set("")

    password = my_Password.get()
    my_Password.set("")

    client_socket.send(bytes("Name:" + name, "utf8"))

    salt = client_socket.recv(BUFSIZ).decode("utf8")[len('Salt:'):]

    hashed_password = hashlib.sha512((password + salt).encode()).hexdigest()
    client_socket.send(bytes("Password:" + hashed_password, "utf8"))

    msg = client_socket.recv(BUFSIZ).decode("utf8")

    if (msg == "PASSWORD IS INCORRECT OR USERNAME IS ALREADY TAKEN"):
        label = ttk.Label(top, text=msg)
        label.pack(side="top", fill="x", pady=10)
    else:
        msg_list["state"] = tkinter.NORMAL
        entry_field["state"] = tkinter.NORMAL
        send_button["state"] = tkinter.NORMAL
        showAllNames_button["state"] = tkinter.NORMAL

        login_signup_button["state"] = tkinter.DISABLED
        name_field["state"] = tkinter.DISABLED
        Password_field["state"] = tkinter.DISABLED

        receive_thread = Thread(target=receive)
        receive_thread.start()
        print(name, 'logged in successfully')


## Choose someone##
def returnAll(event=None):
    client_socket.send(bytes("GetAllContacts", "utf8"))
 
 
def on_closing(event=None):
    """This function is to be called when the window is closed."""
    my_msg.set("{quit}")
    send()


# key
# key = get_random_bytes(16)
crypto_steganography = CryptoSteganography('My secret password key')

##################################################################################
##################################LOG IN/SIGN UP PAGE#############################

top = tkinter.Tk()
top.title("Chatter")

login_signup_button = tkinter.Button(top, text="Log in/Sign up", command=login_signup)
login_signup_button["state"] = tkinter.NORMAL
login_signup_button.pack(side=tkinter.BOTTOM)

my_name = tkinter.StringVar()
name_field = tkinter.Entry(top, textvariable=my_name)
name_field.bind("<Return>", login_signup)
name_field.pack(side=tkinter.BOTTOM)

my_Password = tkinter.StringVar()
Password_field = tkinter.Entry(top, textvariable=my_Password)
Password_field.bind("<Return>", login_signup)
Password_field.pack(side=tkinter.BOTTOM)
Password_field.config(show="*")
##################################LOG IN/SIGN UP PAGE#############################
##################################################################################


## Choose someone##
showAllNames_button = tkinter.Button(top, text="Show all", command=returnAll)
 
showAllNames_button["state"] = tkinter.DISABLED
 
 
showAllNames_button.pack(side=tkinter.LEFT)
 
# canvas = Canvas(top, width = 300, height = 300)  
# canvas["state"]=tkinter.DISABLED
# canvas.pack()
#############
messages_frame = tkinter.Frame(top)
my_msg = tkinter.StringVar()  # For the messages to be sent.
my_msg.set("Type your messages here.")
scrollbar = tkinter.Scrollbar(
    messages_frame)  # To navigate through past messages.
 
 
 
# Following will contain the messages.
msg_list = tkinter.Listbox(messages_frame, height=15, width=50, yscrollcommand=scrollbar.set)
scrollbar.pack(side=tkinter.RIGHT, fill=tkinter.Y)
msg_list.pack(side=tkinter.LEFT, fill=tkinter.BOTH)
msg_list.pack()
messages_frame.pack()
msg_list["state"] = tkinter.DISABLED

entry_field = tkinter.Entry(top, textvariable=my_msg)
entry_field.pack()
entry_field["state"] = tkinter.DISABLED

# TODO: bind to the currently enabled button
entry_field.bind("<Return>", send)

send_button = tkinter.Button(top, text="Send", command=send)
send_button["state"] = tkinter.DISABLED
send_button.pack()

 
 
top.protocol("WM_DELETE_WINDOW", on_closing)
 
#----Now comes the sockets part----
 
# HOST = input('Enter host: ')
# PORT = input('Enter port: ')
HOST='127.0.0.1'
PORT=8080
# if not PORT:
#     PORT = 33000
# else:
#     PORT = int(PORT)
 
BUFSIZ = 1024
ADDR = (HOST, PORT)
 
client_socket = socket(AF_INET, SOCK_STREAM)
client_socket.connect(ADDR)
 
 
# receive_thread = Thread(target=receive)
# receive_thread.start()
tkinter.mainloop()  # Starts GUI execution.
