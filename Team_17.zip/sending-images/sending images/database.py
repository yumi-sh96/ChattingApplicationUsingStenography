import pymongo
from pymongo import MongoClient 
  
# Connect with the portnumber and host 
client = MongoClient('localhost', 27017)
  
# Access database 
db = client.chat_app
  
# Access collection of the database 
users = db.users
  
# dictionary to be added in the database 
# record = { 
# 'username': 'nada',
# 'password': '1234'
# } 
  
# # inserting the data in the database 
# users.insert_one(record) 

# res = users.find_one({'username': 'nada'})

# print(res['password'])