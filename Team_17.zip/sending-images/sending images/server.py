##REFERENCE:
 
##https://m...content-available-to-author-only...m.com/swlh/lets-write-a-chat-app-in-python-f6783a9ac170?fbclid=IwAR1PEA5Bxaglt6l_ojyzeYSht772Ut-mYzvNjuNdps90Iq_H0MAbDbR2cj0
 
"""Server for multithreaded (asynchronous) chat application."""
from socket import AF_INET, socket, SOCK_STREAM
from threading import Thread
import cv2
import uuid
from database import users
from PIL import Image
import io

def pad(s, bs):
    return s.ljust(bs, b'\x0f')

def unpad(s):
    return s.rstrip(b'\x0f') 
 
def accept_incoming_connections():
    """Sets up handling for incoming clients."""
    while True:
        client, client_address = SERVER.accept()
 
        print("%s:%s has connected." % client_address)
        # client.send(bytes("Greetings from the cave! Now type your name and press enter!", "utf8"))
        addresses[client] = client_address
        Thread(target=handle_client, args=(client,)).start()
 
 
def handle_client(client):  # Takes client socket as argument.
    """Handles a single client connection."""
    correct_info = False
    while (not correct_info):
        print('in the loop')
        rec_name = (client.recv(BUFSIZ))[len('Name:'):].decode("utf8")
        print('name received')

        user = users.find_one({'username': rec_name})
        if user:
            salt = user['salt']
            client.send(bytes("Salt:" + salt, "utf8"))
            print('server: old user, sent salt')

            password = user['password']
            rec_password = (client.recv(BUFSIZ))[len('Password:'):].decode("utf8")
            if rec_password == password:
                print('server: old user, correct password')
                correct_info = True
                client.send(bytes("Logged in successfully", "utf8"))
            else:
                print('server: old user, incorrect password')
                client.send(bytes("PASSWORD IS INCORRECT OR USERNAME IS ALREADY TAKEN", "utf8"))
        else:
            print("server: new user", user)
            salt = uuid.uuid4().hex
            client.send(bytes("Salt:" + salt, "utf8"))
            print('server: new user, sent salt')

            rec_password = (client.recv(BUFSIZ))[len('Password:'):].decode("utf8")

            record = {
                'username': rec_name,
                'password': rec_password,
                'salt': salt,
            }

            print('before inserting')
            users.insert_one(record) 
            print('after inserting')
            correct_info = True
            client.send(bytes("Logged in successfully", "utf8"))

    print('server: out of loop')
    name = rec_name
    welcome = 'Welcome %s! If you ever want to quit, type {quit} to exit.' % name
    client.send(bytes(welcome, "utf8"))
    msg = "%s has joined the chat!" % name
 
    broadcast(bytes(msg, "utf8"))
    clients[client] = {'name':name}
    private = False
    target_client_socket = None
    reply_to_client_socket = None


    while True:
        msg = client.recv(BUFSIZ)
        # print("server received", msg.decode("utf8"))
        print("DECODING", (msg[:4]).decode("utf8"))
        print(len(msg))

        if 'size:' == (msg[0:len('size:')]).decode("utf-8"):
            msg = unpad(msg)
            msg = msg.decode("utf-8")
            msg = msg[len('size:'):]
            length = int(msg)
            print('size received:', length)

            data = b''
            while(len(data) < length):
                data += client.recv(BUFSIZ)

            print('image received')

            image = Image.open(io.BytesIO(data))
            image.save('image at server.png')

            msg = 'size:' + str(length) + ':' + name
            msg = bytes(msg, "utf8")
            msg = pad(msg, BUFSIZ)

            print("NAME", name)
            print("PRIVATE", private)

            if private == False:
                broadcast(msg)
                broadcast(data, image=True)
            else:
                print("PRIVATE MSG")
                if(target_client_socket):
                    target_client_socket.send(msg)
                    target_client_socket.sendall(data)
                if(reply_to_client_socket):
                    reply_to_client_socket.send(msg)
                    reply_to_client_socket.sendall(data)

        elif 'GetAllContacts' == (msg[0:len('GetAllContacts')]).decode("utf-8"):
            all_contacts = "Contacts: "
            for key, clt in clients.items():
                all_contacts += clt['name'] + " , "

            msg = bytes(all_contacts, "utf8")
            msg = pad(msg, BUFSIZ)
            client.send(msg)
 
 
        elif 'send to ' == (msg[0:len('send to ')]).decode("utf-8"):
            msg = unpad(msg)
            target_client_name = msg[len('send to '):].decode("utf8")
            client_name = clients[client]['name']

            found = False
            for key, clt in clients.items():
                if clt['name'] == target_client_name:                    
                    found = True
                    target_client_socket = key
                    reply_to_client_socket = client
                    private = True

                    reply_to_msg = bytes("PRIVATE CHAT STARTED WITH " + target_client_name, "utf8")
                    reply_to_msg = pad(reply_to_msg, BUFSIZ)

                    target_msg = bytes("PRIVATE CHAT STARTED WITH " + name, "utf8")
                    target_msg = pad(target_msg, BUFSIZ)
 
                    reply_to_client_socket.send(reply_to_msg)
                    target_client_socket.send(target_msg)
 
                    break
 
            if not found:
                msg = bytes("This person doesn't exist", "utf8")
                msg = pad(msg, BUFSIZ)
                client.send(msg)
 
        elif 'reply to '== (msg[0:len('reply to ')]).decode("utf-8"):
            msg = unpad(msg)
            reply_to_client_name = msg[len('reply to '):].decode("utf8")
            found = False
            for key, clt in clients.items():
                if clt['name'] == reply_to_client_name:
                    found = True
                    reply_to_client_socket = key
                    target_client_socket = client
                    private = True
                    
                    reply_to_msg = bytes(name + " ACCEPTED CHATTING WITH YOU", "utf8")
                    reply_to_msg = pad(reply_to_msg, BUFSIZ)

                    target_msg = bytes("YOU ACCEPTED THE CHAT WITH " + reply_to_client_name, "utf8")
                    target_msg = pad(target_msg, BUFSIZ)

                    target_client_socket.send(target_msg)
                    reply_to_client_socket.send(reply_to_msg)
 
                    break
 
            if not found:
                msg = bytes("This person doesn't exist", "utf8")
                msg = pad(msg, BUFSIZ)
                client.send(msg)
 
        elif 'back' == (msg[0:len('back')]).decode("utf-8"):
            if private:
                target_client_socket.send(bytes(name+" LEFT PRIVATE CHAT", "utf8"))
                reply_to_client_socket.send(bytes(name+" LEFT PRIVATE CHAT", "utf8"))
                private = False
                target_client_socket = None
                reply_to_client_socket = None
        else:
            msg = unpad(msg)
            print("QUIT", msg.decode("utf8"))

            msg = bytes("{quit}", "utf8")
            msg = pad(msg, BUFSIZ)
            client.send(msg)
            client.close()
            del clients[client]

            msg = bytes("%s has left the chat." % name, "utf8")
            msg = pad(msg, BUFSIZ)

            broadcast(msg)
            break
 
 
def broadcast(msg, image=False):  # prefix is for name identification.
    """Broadcasts a message to all the clients."""
 
    for sock in clients:
        if image:
            sock.sendall(msg)
        else:
            sock.send(msg)
 
clients = {}
addresses = {}
 
HOST = '127.0.0.1'
PORT = 8080
BUFSIZ = 1024
ADDR = (HOST, PORT)
 
SERVER = socket(AF_INET, SOCK_STREAM)
SERVER.bind(ADDR)

if __name__ == "__main__":
    SERVER.listen(5)
    print("Waiting for connection...")
    print("Host is: ", HOST)
    print("Port is: ", PORT)
    ACCEPT_THREAD = Thread(target=accept_incoming_connections)
    ACCEPT_THREAD.start()
    ACCEPT_THREAD.join()
SERVER.close()
